/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventario;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Conexion implements Connection{
        
        public Conexion(){  
            try{
            Class.forName("com.mysql.jdbc.Driver");
            
            //Connection con = DriverManager.getConnection("jdbc:mysql://localhost/inventario", "root", "30dpr4319n");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/inventario?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=GMT-6", "root", "30dpr4319n");
            
            System.out.println("Conexion con la base de datos exitosa");
            
        }catch(SQLException e){
            System.out.println("La excepcion es: "+e.getMessage());
        }catch(ClassNotFoundException a){
            System.out.println("La clase no se encontro");
        }catch(Exception b){
            System.out.println("La excepcion es: "+b.getMessage());
        }
        }
        
       
        
       
}
    

    /*Statement PrepareStatement(String insert_into_producto_VALUES) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Statement createStatement() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
     
        
    }
*/
