package inventario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
//import inventario.Conexion;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class Inventario {

PreparedStatement st;
        
        public static PreparedStatement state = null;

//MENU DEL PROGRAMA
public static void menu(Connection c){
            Scanner s = new Scanner(System.in);
            boolean x = true;
            int op;

            while(x){
                System.out.println("\n\t\t---ELIGE UNA OPCION---\n\n");
                System.out.println("1.- Agregar");
                System.out.println("2.- Mostrar");
                System.out.println("3.- Eliminar");
                System.out.println("4.- Actualizar");
                System.out.println("5.- Ventas");
                System.out.println("6.- Salir");
            
                op = s.nextInt();
            
                if(op > 5){
                    System.out.println("Inserta una opcion valida");
                }
                if(op == 1){
                    agregar(c);
                }
                if(op == 2){
                    mostrar(c);
                }
                if(op == 3) {
                    eliminar(c);
                }
                if (op == 4) {
                    actualizar(c);
                }
                if(op == 5){
                    ventas(c);
                }
                if(op==6){
                    x = false;
        }
    }
}
//AGREGAR DATOS
public static void agregar(Connection c){
               System.out.println("Funciono");
               
            try{
               
                Scanner sc = new Scanner(System.in);
                Scanner sc2 = new Scanner(System.in);
                //ResultSet set = null;
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventario?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=GMT-6", "root", "30dpr4319n");
                PreparedStatement st = con.prepareStatement("INSERT INTO producto VALUES(?,?,?,?,?,?)");
                    
                int clave, cp;
                String nombre, descripcion, unidad;
                float precio, cantidad;
                
                System.out.println("Funciono");                    
                System.out.println("¿Cuantos productos desea agregar?");
                cp = sc.nextInt();
                
                for(int i = 1; i<=cp; i++){
                    System.out.println("Escriba la clave del producto "+i+" : ");
                        clave = sc.nextInt();
                        System.out.println("Escriba el nombre del producto "+i+" : ");
                        nombre = sc2.nextLine();
                        System.out.println("Escribe la descripcion del producto "+i+" : ");
                        descripcion = sc2.nextLine();
                        System.out.println("Escribe el tipo de unidad "+i+" : ");
                        unidad = sc2.nextLine();
                        System.out.println("Digite el precio del producto "+i+" : ");
                        precio = sc.nextFloat();
                        System.out.println("Digite la cantidad del producto "+i+" : ");
                        cantidad = sc.nextFloat();
                        try{
                            st.setInt(1,clave);
                            st.setString(2,nombre);
                            st.setString(3, descripcion);
                            st.setString(4, unidad);
                            st.setFloat(5, precio);
                            st.setFloat(6, cantidad);
                            st.executeUpdate();
                         }catch(SQLException e){
                             System.out.println("La excepcion es: "+e.getMessage());
                         }
                    }
                        }catch (NullPointerException e){
                            System.out.println(e.getMessage());
                        }catch(Exception e){
                            System.out.println("La excepcion es: "+e.getMessage());
                    }    
          }    
//MOSTRAR DATOS 
public static void mostrar (Connection c){
            try{
               //Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventario?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=GMT-6", "root", "30dpr4319n");
                state = con.prepareStatement("SELECT * FROM producto");
               //Statement stmt = c.createStatement();
                ResultSet resultado = state.executeQuery();
        
        
                System.out.println("Clave: \t Nombre: \t Descripcion: \t Unidad: \t Precio: \t Cantidad: "+resultado);
                while(resultado.next()){
                System.out.println(resultado.getString("clave")+"\t"+resultado.getString("nombre")+"\t"+resultado.getString("descripcion")
                +"\t"+resultado.getString("unidad")+"\t"+resultado.getString("precio")+"\t"+resultado.getString("cantidad")+"\t");
                }
            }catch(SQLException x){
                    System.out.println("La excepcion es: "+x.getMessage());
            }catch(Exception a){
                    System.out.println("La excepcion es: "+a);
    }  
}
//ELIMINAR DATOS
public static void eliminar(Connection c){
    try{
        int key;
        Scanner scan = new Scanner(System.in);
        c = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventario?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=GMT-6", "root", "30dpr4319n");
        System.out.println("Digite la clave del producto que desea eliminar: ");
        key = scan.nextInt();

        state = c.prepareStatement("DELETE FROM producto WHERE clave=?");
        state.setInt(1,key);
        int filasBorradas = state.executeUpdate();
        if(filasBorradas>0){
            System.out.println("Las filas se han borrado correctamente");
        }
    }catch(SQLException e){
        System.out.println("La excepción es: "+e.getMessage());
    }catch(NullPointerException a){
        System.out.println("La excepcion es: "+a.getMessage());
    }catch(Exception d){
        System.out.println("La excepción es: "+d.getMessage());
    }
}
//FUNCIÓN PARA ACTUALIZAR DATOS
public static void actualizar(Connection c){
    
    Scanner scan = new Scanner(System.in);
    Scanner scan2 = new Scanner(System.in);
    try{

        int key, clave;
        String nombre, descripcion, unidad;
        float precio, cantidad;
        c = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventario?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=GMT-6", "root", "30dpr4319n");
        System.out.println("Digite la clave del producto que desea actualizar");
        key = scan.nextInt();

        PreparedStatement p = c.prepareStatement("UPDATE producto SET clave=?, nombre=?, descripcion=?, unidad=?, precio=?, cantidad=? WHERE clave =?");
        System.out.println("Digite la nueva clave del producto: ");
        clave = scan.nextInt();
        System.out.println("Escriba el nuevo nombre del producto");
        nombre = scan2.nextLine();
        System.out.println("Escriba la nueva descripcion del producto");
        descripcion = scan2.nextLine();
        System.out.println("Escriba el tipo de unidad del producto");
        unidad = scan2.nextLine();
        System.out.println("Digite el nuevo precio del producto");
        precio = scan.nextFloat();
        System.out.println("Digite la cantidad del producto");
        cantidad = scan2.nextFloat();

        p.setInt(1, clave);
        p.setString(2, nombre);
        p.setString(3, descripcion);
        p.setString(4, unidad);
        p.setFloat(5, precio);
        p.setFloat(6, cantidad);
        p.setInt(7, key);
        
        p.executeUpdate();
        
    }catch(SQLException e){
        System.out.println("La excepcion es: "+e.getMessage());
    }   
}
public static void main(String[] args) {
    Connection c = null;
    menu(c);

    }
}
        
    

