Para hacer la conexión a la base de datos utilicé el conector

mysql-connector-java-8.0.19

Además utilicé el comando:

conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Inventario?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=GMT-6", "root", "57d85e498a");

Esto debido a que la zona horaria no coincidía
